# NodeJsFileUpload

A sample application to demonstrate file upload with node.js and express

You can find a blog post about it at following location.

How to upload file with Express,Pug and Multer in Node.js- http://www.dotnetjalps.com/2017/01/file-upload-express-nodejs.html

